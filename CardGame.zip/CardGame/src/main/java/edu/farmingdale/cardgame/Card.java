package edu.farmingdale.cardgame;

public class Card {
    public enum Face {Ace, Two, Three, Four, Five, Six, Seven, Eight, Nine, Ten, Jack, Queen, King}
    public enum Suit {Clubs, Diamonds, Hearts, Spades}

    private final Face face;
    private final Suit suit;

    public Card(Face face, Suit suit) {
        this.face = face;
        this.suit = suit;
    }

    // ✅ Returns correct face value format that matches filenames
    public String getFaceValue() {
        switch (face) {
            case Ace: return "ace";
            case Two: return "2";
            case Three: return "3";
            case Four: return "4";
            case Five: return "5";
            case Six: return "6";
            case Seven: return "7";
            case Eight: return "8";
            case Nine: return "9";
            case Ten: return "10";
            case Jack: return "jack";
            case Queen: return "queen";
            case King: return "king";
            default: throw new IllegalArgumentException("Invalid card face");
        }
    }

    public Suit getSuit() {
        return suit;
    }

    @Override
    public String toString() {
        return getFaceValue() + " of " + suit.name().toLowerCase();
    }
}


