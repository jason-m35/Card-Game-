package edu.farmingdale.cardgame;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class CardController {

    @FXML private ImageView card1Image;
    @FXML private ImageView card2Image;
    @FXML private ImageView card3Image;
    @FXML private ImageView card4Image;
    @FXML private TextField expressionField;
    @FXML private Button verifyButton;
    @FXML private Button refreshButton;
    @FXML private Button findSolutionButton;

    private DeckOfCards deck;

    public void initialize() {
        deck = new DeckOfCards();
        updateCardImages();
    }

    private void updateCardImages() {
        List<Card> selectedCards = deck.getSelectedCards();

        // Load images based on the card values
        card1Image.setImage(loadCardImage(selectedCards.get(0)));
        card2Image.setImage(loadCardImage(selectedCards.get(1)));
        card3Image.setImage(loadCardImage(selectedCards.get(2)));
        card4Image.setImage(loadCardImage(selectedCards.get(3)));
    }

    private Image loadCardImage(Card card) {
        String imagePath = "/edu/farmingdale/cardgame/cards/"
                + card.getFaceValue()
                + "_of_"
                + card.getSuit().name().toLowerCase()
                + ".png";

        System.out.println("Loading image from path: " + imagePath);

        java.io.InputStream imageStream = getClass().getResourceAsStream(imagePath);

        if (imageStream == null) {
            System.out.println("Error: Image not found at " + imagePath);
            return null;
        }

        return new Image(imageStream);
    }

    @FXML
    private void refreshCards() {
        deck.shuffleDeck();
        deck.selectFourCards();
        updateCardImages();
    }

    @FXML
    private void verifyExpression() {
        String userInput = expressionField.getText().trim();

        if (userInput.isEmpty()) {
            showAlert("Invalid Input", "Please enter an expression.");
            return;
        }

        if (!isValidExpression(userInput)) {
            showAlert("Invalid Expression", "The numbers in your expression do not match the selected cards.");
            return;
        }

        try {
            double result = evaluateExpression(userInput);

            if (result == 24) {
                showAlert("Success!", "Your expression is correct! 🎉");
            } else {
                showAlert("Incorrect", "Your expression does not evaluate to 24.");
            }

        } catch (Exception e) {
            showAlert("Error", "Invalid mathematical expression.");
        }
    }

    @FXML
    private void findSolution() {
        List<Integer> cardValues = new ArrayList<>();
        for (Card card : deck.getSelectedCards()) {
            try {
                cardValues.add(Integer.parseInt(card.getFaceValue())); // ✅ Convert String to Integer
            } catch (NumberFormatException e) {
                showAlert("Error", "Invalid card value: " + card.getFaceValue());
                return;
            }
        }

        String solution = solve24(cardValues);

        if (solution == null) {
            showAlert("No Solution", "No valid equation found to reach 24.");
        } else {
            expressionField.setText(solution);
        }
    }


    private String solve24(List<Integer> numbers) {
        List<String> operators = List.of("+", "-", "*", "/");

        // Try all possible permutations of numbers and operators
        for (int a : numbers) {
            for (int b : numbers) {
                if (b == a) continue;
                for (int c : numbers) {
                    if (c == a || c == b) continue;
                    for (int d : numbers) {
                        if (d == a || d == b || d == c) continue;

                        for (String op1 : operators) {
                            for (String op2 : operators) {
                                for (String op3 : operators) {
                                    String expression = String.format("(%d %s (%d %s (%d %s %d)))", a, op1, b, op2, c, op3, d);
                                    if (evaluateExpression(expression) == 24) {
                                        return expression;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return null; // No solution found
    }

    // ✅ Custom Math Evaluator (Replaces JavaScript Engine)
    private double evaluateExpression(String expression) {
        try {
            return evaluateMathExpression(expression);
        } catch (Exception e) {
            return -1;
        }
    }

    private double evaluateMathExpression(String expression) {
        Stack<Double> numbers = new Stack<>();
        Stack<Character> operators = new Stack<>();
        StringBuilder num = new StringBuilder();

        for (char c : expression.toCharArray()) {
            if (Character.isDigit(c)) {
                num.append(c);
            } else if (c == '+' || c == '-' || c == '*' || c == '/') {
                if (num.length() > 0) {
                    numbers.push(Double.parseDouble(num.toString()));
                    num.setLength(0);
                }
                while (!operators.isEmpty() && precedence(c) <= precedence(operators.peek())) {
                    compute(numbers, operators);
                }
                operators.push(c);
            }
        }
        if (num.length() > 0) {
            numbers.push(Double.parseDouble(num.toString()));
        }
        while (!operators.isEmpty()) {
            compute(numbers, operators);
        }
        return numbers.pop();
    }

    private int precedence(char op) {
        return (op == '+' || op == '-') ? 1 : (op == '*' || op == '/') ? 2 : 0;
    }

    private void compute(Stack<Double> numbers, Stack<Character> operators) {
        if (numbers.size() < 2 || operators.isEmpty()) return;
        double b = numbers.pop();
        double a = numbers.pop();
        char op = operators.pop();
        switch (op) {
            case '+': numbers.push(a + b); break;
            case '-': numbers.push(a - b); break;
            case '*': numbers.push(a * b); break;
            case '/': numbers.push(a / b); break;
        }
    }

    private boolean isValidExpression(String expression) {
        List<String> validNumbers = new ArrayList<>();
        for (Card card : deck.getSelectedCards()) {
            validNumbers.add(String.valueOf(card.getFaceValue()));
        }

        String[] tokens = expression.split("[^0-9]+");
        for (String token : tokens) {
            if (!token.isEmpty() && !validNumbers.contains(token)) {
                return false;
            }
        }
        return true;
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
