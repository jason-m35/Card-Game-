package edu.farmingdale.cardgame;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class DeckOfCards {
    private final List<Card> deck = new ArrayList<>();
    private final List<Card> selectedCards = new ArrayList<>();

    public DeckOfCards() {
        // Create a full deck of 52 cards
        for (Card.Suit suit : Card.Suit.values()) {
            for (Card.Face face : Card.Face.values()) {
                deck.add(new Card(face, suit));
            }
        }
        shuffleDeck();
        selectFourCards();
    }

    // ✅ Shuffle the deck randomly
    public void shuffleDeck() {
        Collections.shuffle(deck);
    }

    // ✅ Select four new cards after shuffling
    public void selectFourCards() {
        shuffleDeck();  // Ensures randomness before selection
        selectedCards.clear();
        for (int i = 0; i < 4; i++) {
            selectedCards.add(deck.get(i));
        }
    }

    // ✅ Return the selected four cards
    public List<Card> getSelectedCards() {
        return selectedCards;
    }
}





