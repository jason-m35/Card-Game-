module edu.farmingdale.cardgame {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.scripting;

    opens edu.farmingdale.cardgame to javafx.fxml;
    exports edu.farmingdale.cardgame;
}
